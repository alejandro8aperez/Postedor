
README - Validación térmica (SALOME + Elmer)

1) Geometría y malla (SALOME):
   - Cree 4 sólidos: Toroide (BodyID=1), Tanque (2), Araña (3), Poste (4).
   - Defina grupos de superficie para las paredes externas expuestas al aire y asígneles Physical IDs 10, 11, 12.
   - Exporte la malla a formato UNV en una carpeta 'mesh' junto al .sif.

2) Elmer (Heat):
   - Copie 'template_termico_elmer.sif' a la carpeta del caso.
   - Edite los parámetros al final del .sif: Tamb, h_ext, Q_W y V_toroide.
   - Ajuste Materiales si dispone de datos más precisos.
   - Ejecute: ElmerGrid 8 2 mesh.unv -out mesh
              ElmerSolver template_termico_elmer.sif

3) Casos sugeridos:
   - 5 kVA: Q_W ≈ 0.025*5000 = 125 W (Base) o 0.032*5000 = 160 W (Worst)
   - 10 kVA: 250–320 W
   - 15 kVA: 375–480 W
   - 25 kVA: 625–800 W
   - 30 kVA: 750–960 W

4) Criterio Clase B:
   - Max(Temperature) ≤ 403.15 K (130 °C).

Notas:
   - Para Worst-Case reduzca h_ext a 5.5 W/m2K y considere menor área efectiva.
   - Puede modelar la conductancia de contacto araña–tanque–poste con 'Heat Equation' interfaces o capas delgadas con k elevado.
